﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。

define yy = Character("月羽",color="#c09bf7ff")
define lwx = Character("林挽星",color="#ad51cb")
define yn = Character("你",color="#00c8ffff")
define lfkz = Character("科长",color="#b98a44")
define yh = Character("于寰（你）",color="#3892ed")

define flag = 0

image stars:
    "images/stars.png"
    zoom 0.75

image cx:
    "images/cx.png"
# 游戏在此开始。
transform tip_fade:
    alpha 0.0
    alpha 1.0 0.15
# ==== screens.rpy 末尾，粘贴这里 ====
default show_info = False

screen choice_with_preview():
    # 默认不显示任何预览图，或者可以设置一个默认图
    default current_image = None

    # --- 预览图片显示区域 ---
    # 只有当 current_image 有值时才显示
    if current_image:
        add current_image:
            xalign 0.1
            yalign 0.5
            zoom 0.75

    # --- 按钮区域 ---
    vbox:
        xalign 0.95
        yalign 0.5
        spacing 20

        # 按钮 1
        textbutton "离璗":
            # 鼠标放上去时，将变量设置为苹果的图片路径
            hovered SetScreenVariable("current_image", "images/ld.png")
            # 鼠标移开时，清空变量（隐藏图片）或设为其他默认图
            unhovered SetScreenVariable("current_image", None)
            # 点击后返回字符串 "apple"
            action Return("ld")

        # 按钮 2
        textbutton "林风":
            hovered SetScreenVariable("current_image", "images/lflc.png")
            unhovered SetScreenVariable("current_image", None)
            # 点击后返回字符串 "banana"
            action Return("lf")

        # 按钮 3
        textbutton "慕宁":
            id "mnbt"
            hovered SetScreenVariable("current_image", "images/mn.png")
            unhovered SetScreenVariable("current_image", None)
            # 点击后返回字符串 "orange"
            action Return("mn")

        textbutton "白栀":
            hovered SetScreenVariable("current_image", "images/bzlh.png")
            unhovered SetScreenVariable("current_image", None)
            # 点击后返回字符串 "orange"
            action Return("bz")
    
transform row_shake:
    xoffset 8
    pause 0.05
    xoffset -8
    pause 0.05
    xoffset 6
    pause 0.05
    xoffset -6
    pause 0.05
    xoffset 0

default affection = 5
default max_affection = 5
default trigger_shake = False

screen heart_bar(a,b,d,tint_color="#ffffff"):
    frame:
        xalign a
        yalign b
        background None
        if trigger_shake:
            hbox:
                at row_shake
                spacing 20
                for i in range(max_affection):
                    frame:
                        xsize 48
                        ysize 48
                        background None
                        if i < affection:
                            add "heart_full.png" xalign 0.5 yalign 0.5 zoom 0.8 alpha d matrixcolor TintMatrix(tint_color)
                        else:
                            add "heart_empty.png" xalign 0.5 yalign 0.5 zoom 0.8 alpha d matrixcolor TintMatrix(tint_color)
        else:
            hbox:
                spacing 20
                for i in range(max_affection):
                    frame:
                        xsize 48
                        ysize 48
                        background None
                        if i < affection:
                            add "heart_full.png" xalign 0.5 yalign 0.5 zoom 0.8 alpha d matrixcolor TintMatrix(tint_color)
                        else:
                            add "heart_empty.png" xalign 0.5 yalign 0.5 zoom 0.8 alpha d matrixcolor TintMatrix(tint_color)
init python:
    def lessheart(a):
        global affection,trigger_shake
        trigger_shake = True
        renpy.pause(0.25)   # 只等待晃动播放完成
        affection -= a
        trigger_shake = False
label start:
    
    # 显示一个背景。此处默认显示占位图，但您也可以在图片目录添加一个文件
    # （命名为 bg room.png 或 bg room.jpg）来显示。

    scene stars
    with  fade

    show cx:
        xpos 500-500
    with dissolve

    # 显示角色立绘。此处使用了占位图，但您也可以在图片目录添加命名为
    # eileen happy.png 的文件来将其替换掉。


    # 此处显示各行对话。

    yy "你好"

    yy "请问一下，你叫什么来着？"
    $ flag = 1
    
    while flag==1:
        $ flag = 0
        python:
            user_name = renpy.input("请输入你的名字：", length=32)
        if user_name=="月羽":
            yy "……你故意的吧，请认真输入"
            $ flag = 1
        elif user_name=="法涅斯":
            scene htzd
            pause 2.0
            return
        elif user_name=="袁智筱":
            scene black
            "你被柠檬果冻淹死哩~"
            return

    yy """

    [user_name]，欢迎来到这个游戏测试服

    首先，这是一个测试服，有些东西做的不好请见谅

    其次，原神启动！

    你说为什么我的形象很像诚弦？
    
    我的oc我爱夺舍就夺舍了！

    （人话：自己立绘还没出将就一下）

    欸顺手抓只林挽星过来玩玩
    """

    show lwx:
        xpos 1420-500
    with dissolve

    yy "铛铛！挽星酱闪亮登场！"

    lwx "？？？"

    yy "好了好了开个玩笑我把挽星酱放回去吧"

    hide lwx
    with dissolve

    yy "欸对了！我可以把这里做成一个番外档案馆合集！"

    jump s1
    
    # 此处为游戏结尾。

    return

label s1:
    menu:
        yy "你有什么想看的吗~"
        "BH猫娘病毒if":
            jump s2
        "月羽亲友的浪漫爱情故事":
            jump s3
        "科长和于寰酱的小开头":
            jump s4
        "不看了":
            yy "再见~"
            yy "欢迎下次光临~"

    return

label s2:
    """
    目前暂缺：

    科长大人的猫娘立绘一份

    所长大人的猫娘立绘一份

    副所长大人的猫娘立绘一份

    慕宁酱的猫娘立绘一份

    ……

    求好心人士赞助
    """

    yy "欸呀，看来不行呢~"
    
    menu:
        yy "要不你赞助点？"
        "再看看":
            jump s1
    return

label s3:
    yy "（两眼放光）你说这个！！！"
    yy "我和你说哦，就是那个……"
    show lfkz:
        xpos 1420-500
    with dissolve
    lfkz "（路过）"
    lfkz "说什么呢让我也听听"
    yy "！！！"
    yy "（目移）"
    yy "没……没什么……"
    yy "（使眼色）"
    yn "对，没什么"
    lfkz "（怀疑）你们最好是"
    yy "你实验做完了没就瞎逛快点回去做你的实验去！"
    hide lfkz
    with dissolve
    menu:
        yy "……今天运气不好啊……算了算了"
        "再看看":
            jump s1
    return

label s4:
    menu:
        yy "……让我看看……天呐居然写完了快夸我！"
        "月羽真棒！":
            yn "不愧是月羽大人！"
            yy "嘿嘿……过奖了过奖了，只是开个玩笑啦……"
            yy "好的……那么让我们来看看……"
            hide cx
            with dissolve
            jump s5
        "那不是你应该做的吗？":
            yy "你……不是[user_name]你什么意思啊？？？"
            yy "行呗那我也没有展示的义务！（生气）"
            yy "你爱上哪儿玩上哪儿去！"
            return
    return
    
label s5:
    scene yjs2
    with fade
    yh """
    我是于寰，年龄不重要性别不重要

    重要的是好不容易找到一家公司，结果还是家黑企！

    不扯那么多...我要开始上班了
    """
    show lfkz:
        xpos 1420-500
    with dissolve
    lfkz """
    是于寰对吗？这里有一个新任务，需要你来一下

    还有，既然你说这里是黑企…唔，难道是面试的记忆没有删完？（托下巴）

    不过无伤大雅，我相信被研究所感化的人远比顽固的人多，
    您最好不要成为一个需要我用物理手段感化的对象
    """
    yh "……"
    scene yjs1
    with fade
    "房间的中央是一台电脑，和一台与之相连的，不知道干什么用的机器"
    yh "所以科长大人叫我过来干什么？我不认为我有在记忆科工作的潜质"
    define kzhgd = 5
    show lfkz:
        xpos 1420-500
    with dissolve

    lfkz "不是记忆科的任务，我只是负责来和你说明一下你的任务目标和完成方法"
    lfkz "最近我们新做了一次实验，然后研究出了一个新的记忆观测手段……"
    yh "哦，所以我要干什么？"
    menu:
        lfkz "不知道你入职的时候和有没有听说过地狱列车？没有也没关系，影响不大"
        "有":
            pass
        "没有":
            lfkz "简单来说，就是某次列车出事故了……"
            yh "……然后呢？"
            lfkz "你看我的眼神，好像对研究所有些怀疑，不过我可以告诉你，研究所与这件事没有任何关系，我们只是恰巧“观测”到了而已"
            yh "好吧"
            lfkz "研究所通过某种方式捕获了死去乘客的灵魂，做了一些人性检测，可以说是满足两位所长个人兴趣的游戏……"
            lfkz "最后嘛……有一对运气和智商不错的男女通过了，研究所给他们复活了，可惜了，当时研究所选人加入的时候我在休假，不然我也想去亲自进入实验"
            yh  "……我竟然一点也不惊讶"
    lfkz """
    总而言之，我们对上次实验进行了一些总结

    而这次是两辆列车因为铁道部门的疏忽相撞了。
    我们显然不会放弃那么好的研究机会……

    于是我们对实验进行了一些改进，同时加入了一些新的“变量”，
    按照所长的话说，比上次更有意思。
    """
    yh "所以我要做的是？听起来没有我负责的内容"
    lfkz "请有耐心，不知你有没有听说过量子平行宇宙？"
    lfkz "每次量子事件发生时，宇宙都会分裂成多个分支，每个分支对应一种可能的结果"
    yh "这和我们的研究有什么关系？"
    lfkz """
    关系不小，研究所的最新技术已经足以捕捉在一个与外界
    不联通的小范围空间内的所有量子宇宙

    同时剔除结果导向过于相近的内容，最后可以得到一些有限的分支

    新的实验其实已经做完了，而你的任务是……对这次实验里所有的
    受试者的记忆的不同分支进行观测

    看你的表情，难道不觉得这个有意思吗？最后完成一篇分析报告交到
    我的办公室就好，我会交给所长的，也算是让你转正的契机
    """
    yh "好"
    lfkz "现在由我来教你如何操作这台记忆观测机器试验版"
    yh "……这台机器真的安全吗？"
    lfkz "不知道，不过如果你不幸意外身亡了研究所会用复制体复活你的，不用担心"
    yh "……真是草菅人命啊"
    "科长似乎像是没听到，还在调试着电脑上的参数"
    "然后他把一个像是头盔一样的物品戴到了于寰的脑袋上"
    scene hpsz
    with fade
    "于寰只觉得眼前一黑，再次睁眼，眼前是一片巨大的屏幕，上面跳跃着一些绿色的数字"
    scene black
    with fade
    $ jccs=0
    while jccs!=3:
        menu:
            "很快，数字都消失了，只留下一行白色的“操作流程演示”静静地漂浮在黑色的空间里"
            "操作流程演示":
                pass
        scene stars
        with fade
        show cx:
            xpos 500-500
        with dissolve
        "月羽（你）" """
        （这种通过别人视角看世界的感觉，好神奇）

        今天又是愉快的一天呢～让我去看看我家好亲友都在干什么？

        （好神奇，明明我没想说话，声音就自己发出来了）

        （完全控制不了自己的行动……）
        """
        menu:
            "月羽（你）" "（欸？眼前怎么跳选项了？）"
            "看手机":
                scene black
                "月羽打开了自己的手机，但是你只来得及看到了最上面的“清月”二字，眼前的一切就都回到了黑暗"
                "你听到了科长的声音"
                lfkz "啧，麻烦，居然把一些需要清除的东西当作原料投到机器里了，看来……"
                "（后面的声音模糊不清）"
                
            "不看手机":
                "月羽（你）" "算了算了，不管他们了……我还有活要干呢"
                scene black
                with fade
                "眼前的一切渐渐回归了黑暗"
        lfkz "总而言之，你大概也明白要怎么做了吧，你可以在每个关键节点，切换到不同的平行宇宙中的记忆进行对于不同节点的观测"
        menu:
            lfkz "需要的话也可以随时存档以及返回存档"
            "我明白了":
                $ jccs=3
            "我没明白":
                $ jccs+=1
                if jccs==3:
                    lfkz "于寰，我相信你是个聪明人，请不要浪费时间，你要做完这个任务才能下班"
                else:
                    pass
    menu:
        "请选择记忆观测视角":
            pass
    show lfkz:
        alpha 0.1
        xpos 1420-500
    with dissolve
    show screen heart_bar(0.98,0.2,0.2,tint_color="#ffffff")
    default lfcs=0
    while affection > 0:
        $ res = renpy.call_screen("choice_with_preview")
        if res == "mn":
            jump s6
        else:
            if res=="lf":
                $ lfcs+=1
            if affection==5:
                $ lessheart(2)
                lfkz "……看到慕宁那两个字了吗？"
            elif affection==3:
                $ lessheart(2)
                lfkz "你是不小心的还是故意的？"
            elif affection==1:
                $ lessheart(1)
                if lfcs==3:
                    lfkz "您是否知道些什么？真的对他的事这么感兴趣吗？不过我想你很快就会知道答案了，因此不急于一时"
                else:
                    lfkz "研究所很欢迎异想天开的家伙，前提是你能做到异想天开的人所坐的位置"
                    lfkz "您还是乖乖听话"
                show screen choice_with_preview
                python:
                    renpy.set_focus("choice_with_preview", "mnbt")
                pause 0.5
                lfkz "我来教你"
                jump s6

    return

label s6:
    hide screen heart_bar
    scene black
    with fade
    show cx:
        xpos 500-500
    with dissolve
    yy "以上内容仅为测试部分，不代表上线效果，请见谅～"
    return



    